from .function import *

class webAnalyze():
    def test(self):
        testAnalyze()