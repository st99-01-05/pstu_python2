## License

MIT

**Free Software, webAnalyze!**